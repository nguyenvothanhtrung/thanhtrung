<?php 
    $a = 5;
    $b = 3;
    $tong = $a + $b;
    echo "Tong: $tong <br>";
    $hieu = $a - $b;
    echo "Hieu: $hieu <br>";
    $tich = $a * $b;
    echo "Tich: $tich <br>";
    $thuong = $a / $b;
    echo "Thuong: $thuong <br>";
    $sodu = $a % $b;
    echo "So du: $sodu <br>";
    $ss_bang = $a == $b;
    echo "So sanh bang: $ss_bang <br>";
    $ss_khac = $a != $b;
    echo "So sanh khac: $ss_khac <br>";
    $ss_lon_hon = $a > $b;
    echo "So sanh lon hon: $ss_lon_hon <br>";
    $a++; //$a = $a + 1;
    $a--; //$a = $a - 1;
?>