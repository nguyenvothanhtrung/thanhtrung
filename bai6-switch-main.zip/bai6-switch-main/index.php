<?php
    $n=5;
    switch($n){
        case 2:
            echo 'thu 2';
            break;
        case 3:
            echo 'thu 3';
            break;
        case 4:
            echo 'thu 4';
            break;
        case 5:
            echo 'thu 5';
            break;
        case 6:
            echo 'thu 6';
            break;
        case 7:
            echo 'thu 7';
            break;
        default:
            echo 'Khong phai ngay trong tuan';
    }
?>