<?php
    $a = 5;
    $A = 10;
    echo $a;
    echo '<br>';
    echo $A;
    echo '<br>';
    define('PI', 3.14);
    echo PI;
    echo '<br>';
    $str = 'Hello World';
    echo $str;
?>