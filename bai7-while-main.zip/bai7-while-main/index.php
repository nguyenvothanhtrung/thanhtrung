<?php
//tinh tong tu 1 den 100
$i = 0;
$tong = 0;
while($i <= 100){
    $tong += $i;
    $i++;
}
echo "Tong: $tong";
?>